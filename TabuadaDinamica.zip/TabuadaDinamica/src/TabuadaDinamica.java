import java.util.Scanner;
public class TabuadaDinamica {
    public static void main (String[] args){
        Scanner leitor = new Scanner (System.in);

        //1. Entrada de dados
        System.out.println("=== SIMULADOR DE TABUADA ===");
        System.out.print("Digite um número inteiro para ver sua tabuada: ");
        int numero = leitor.nextInt();

        System.out.println("\nTabuada do " + numero + ":");
        System.out.println("---------------------------");

        // 2. Estrutura Repetição (Laço For)
        // i começa em 1; continua enquanto for menor ou igual a 10; aumenta 1 por volta
        for (int i = 1; i <= 10; i++) {
            int resultado = numero * i;
             System.out.println(numero + " x " + i + " = " + resultado);
        }

        System.out.println("-----------------");

        leitor.close();
    }
}
